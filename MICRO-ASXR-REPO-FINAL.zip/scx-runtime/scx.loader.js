// Outboard SCX loader. Swap this with your actual SCX runtime when ready.
export default { mount(){}, compile(){}, info:'SCX outboard mode' };