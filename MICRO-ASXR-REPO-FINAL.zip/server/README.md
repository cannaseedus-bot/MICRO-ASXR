# ASX-SERVER style relay
Run: `npx json-server --watch db.json --port 8800`
