#!/usr/bin/env bash
npx json-server --watch db.json --port 8800
